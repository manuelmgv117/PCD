﻿namespace ORM.DTO
{
    public class DTO_readUsuario
    {
        public string Username {  get; set; }
        public DateTime Login { get; set; }
    }
}
