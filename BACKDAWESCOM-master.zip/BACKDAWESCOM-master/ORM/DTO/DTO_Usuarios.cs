﻿namespace ORM.DTO
{
    public class DTO_Usuarios
    {
        public string Username { set; get; } = String.Empty;
        public string Password { set; get; } = String.Empty;
    }
}
